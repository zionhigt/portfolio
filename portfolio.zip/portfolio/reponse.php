
<?php
    header('Content-type: application/json');
    header('Access-Control-Allow-Origin: *seb-dev.tech*');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header("Access-Control-Allow-Headers: X-Requested-With");

    $file_messages_path = "./messages.json";
    if($_POST) {
        $message_post;
        $messages_json = NULL;
        if($_POST['name']!='') {
            $message_post['name'] = strip_tags($_POST['name']);
            $message_post['message'] = strip_tags($_POST['message']);
            $message_post['write_at'] = time();

            if(file_exists($file_messages_path)) {
                $messages_json = json_decode(file_get_contents($file_messages_path));

            }
            else {
                if($messages_json == NULL) {
                    $messages_json = new stdClass();
                    $messages_json->messages = [];
                }
            }
            
            if(!in_array($message_post, $messages_json->messages)) {
                $messages_json->messages[] = $message_post;
                file_put_contents($file_messages_path, json_encode($messages_json));

                echo json_encode($messages_json);
                exit();
            }


        }
        
    } else {
        if($_GET['all'] == 1) {
            if(file_exists($file_messages_path)) {
                $messages_json = new stdClass;
                $messages_json->messages = json_decode(file_get_contents($file_messages_path))->messages;
                echo json_encode($messages_json);
                exit();
            }
            else {
                $messages_json = new stdClass();
                $messages_json->messages = [];
                echo json_encode($messages_json);
                exit();
            }
        }
    }
?>